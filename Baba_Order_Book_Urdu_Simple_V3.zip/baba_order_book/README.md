# بابا آرڈر بک — آسان اردو، آف لائن

یہ Android app انٹرنیٹ کے بغیر آرڈر لکھنے کے لیے ہے۔

## app میں کیا ہے
- 80 چیزوں کی تصویریں app کے اندر ہیں۔
- نیا آرڈر بنائیں۔
- دکان کا نام اور فون نمبر لکھیں۔
- چیز کی تصویر دیکھ کر + / − سے تعداد رکھیں۔
- آرڈر فون میں خود محفوظ رہتا ہے۔
- پرانے آرڈر دیکھیں، کاپی کریں، بھیجیں یا مٹا دیں۔
- بیک اَپ بنائیں اور بعد میں واپس لائیں۔
- عام استعمال میں internet، account، server یا monthly fee نہیں۔

## APK مفت میں بنانے کا آسان طریقہ
1. ZIP کو computer میں download کریں۔
2. ZIP کو Extract کریں۔
3. Android Studio install کریں۔
4. Android Studio کھولیں۔
5. Open پر جائیں اور `baba_order_book` والا folder کھولیں۔
6. پہلی بار Gradle/Android SDK کی کچھ files internet سے آ سکتی ہیں۔ یہ صرف setup/build کے لیے ہے۔
7. Project مکمل load ہونے دیں۔
8. اوپر Build پر جائیں۔
9. `Build APK(s)` دبائیں۔
10. APK بن جائے گی۔ اسے phone میں بھیج کر install کریں۔

## ضروری بات
App install ہونے کے بعد آرڈر لکھنے، تصویریں دیکھنے اور پرانے آرڈر دیکھنے کے لیے internet نہیں چاہیے۔

Android Settings میں app کا data صاف نہ کریں اور app uninstall کرنے سے پہلے بیک اَپ بنا لیں، کیونکہ phone میں رکھا data ختم ہو سکتا ہے۔
